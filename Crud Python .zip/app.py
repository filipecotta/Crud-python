from flask import Flask, request, redirect, url_for, render_template
from flask_sqlalchemy import SQLAlchemy
app=Flask(__name__)
app.config["SECRET_KEY"]="chave"
app.config["SQLALCHEMY_DATABASE_URI"]="sqlite:///meubanco.db"
db=SQLAlchemy(app)
class Alunos(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    nome=db.Column(db.String(100),nullable=False)
    nota=db.Column(db.Float)
    observacao=db.Column(db.String(100),nullable=False)
with app.app_context(): db.create_all()
@app.route("/")
def home():
    return render_template("index.html",alunos=Alunos.query.all())
@app.route("/insere",methods=["GET","POST"])
def insere():
    if request.method=="POST":
        db.session.add(Alunos(nome=request.form["nome"],nota=float(request.form["nota"]),observacao=request.form["observacao"]))
        db.session.commit(); return redirect(url_for("home"))
    return render_template("formulario_insere.html")
@app.route("/editar/<int:id>",methods=["GET","POST"])
def editar(id):
    a=Alunos.query.get_or_404(id)
    if request.method=="POST":
        a.nome=request.form["nome"];a.nota=float(request.form["nota"]);a.observacao=request.form["observacao"]
        db.session.commit();return redirect(url_for("home"))
    return render_template("formulario_edita.html",aluno=a)
@app.route("/deletar/<int:id>")
def deletar(id):
    a=Alunos.query.get_or_404(id);db.session.delete(a);db.session.commit();return redirect(url_for("home"))
if __name__=="__main__": app.run(debug=True)